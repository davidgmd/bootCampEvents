package com.example.repo;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.interfaz.ObtenerPersona;

@Repository
public class Repo implements ObtenerPersona{
	@Override
	public ArrayList<String> devolverlistapersona() {
		ArrayList<String> datos = new ArrayList<>();
		datos.add("Agustin");
		datos.add("Sanchez");
		return datos;
	}
}
