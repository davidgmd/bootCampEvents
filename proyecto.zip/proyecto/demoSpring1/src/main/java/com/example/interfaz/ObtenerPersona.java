package com.example.interfaz;

import java.util.ArrayList;

public interface ObtenerPersona {
	public ArrayList<String> devolverlistapersona();
}
