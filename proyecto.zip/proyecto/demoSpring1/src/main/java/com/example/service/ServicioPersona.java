package com.example.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.PersonaEntity;
import com.example.repo.Repo;

@Service
public class ServicioPersona{
	@Autowired
	private Repo repo;
	
	public PersonaEntity solicitarPersonas() {
		PersonaEntity persona1 = this.darformato();
		return persona1;
	}
	
	private PersonaEntity darformato() {
		PersonaEntity persona1 = new PersonaEntity();
		ArrayList<String> datos = repo.devolverlistapersona();
		
		persona1.setNombre(datos.get(0));
		persona1.setApellidos(datos.get(1));
		return persona1;
	}

}
